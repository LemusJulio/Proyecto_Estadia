## Seguridad de Contraseñas - Explicación Detallada

La seguridad de las contraseñas de los usuarios es una de las prioridades fundamentales de este sistema. Hemos implementado un proceso robusto para asegurar que la información de acceso esté protegida en todo momento. A continuación, se explica en detalle cómo gestionamos las contraseñas:

**1. Almacenamiento Exclusivo de Representaciones Seguras (Hashes):**

En lugar de guardar las contraseñas tal como los usuarios las eligen (en texto plano), el sistema almacena una **representación segura** de cada contraseña, conocida como **hash**. Imagina que la contraseña pasa por un proceso irreversible que la transforma en una cadena de caracteres completamente diferente y de longitud fija. Esta cadena resultante es el hash, y es lo único que se guarda en nuestra base de datos.

**¿Por qué no guardamos las contraseñas originales?** Si nuestra base de datos llegara a ser comprometida (un incidente de seguridad muy grave), los atacantes solo tendrían acceso a estos hashes, que son extremadamente difíciles de revertir para obtener las contraseñas originales de los usuarios. Esto reduce significativamente el riesgo de acceso no autorizado a las cuentas.

**2. Utilización del Algoritmo `bcrypt` a través de `password_hash()`:**

Para generar estos hashes seguros, utilizamos una función de PHP llamada `password_hash()`. Esta función implementa un algoritmo de hashing llamado `bcrypt`, que es un estándar de la industria y está diseñado específicamente para el almacenamiento seguro de contraseñas.

**Características importantes de `bcrypt`:**

* **Función Unidireccional:** Como mencionamos, el proceso de hashing es irreversible. No existe una manera práctica de obtener la contraseña original a partir de su hash.
* **Sal (Salt) Aleatoria:** `bcrypt` añade automáticamente un componente aleatorio único, conocido como "sal", a cada contraseña antes de generar el hash. Esto significa que incluso si dos usuarios tienen la misma contraseña, sus hashes almacenados serán diferentes, lo que dificulta los ataques basados en tablas de hashes precalculados (rainbow tables).
* **Factor de Costo (Work Factor):** `bcrypt` permite configurar un "factor de costo" que determina la cantidad de recursos computacionales necesarios para generar el hash. Aumentar el factor de costo hace que el hashing sea más lento, lo que dificulta los ataques de fuerza bruta (intentar adivinar contraseñas probando muchas combinaciones). `password_hash()` utiliza un factor de costo predeterminado que es seguro y se puede ajustar según las necesidades de seguridad.

**3. Proceso de Verificación Seguro con `password_verify()`:**

Cuando un usuario intenta iniciar sesión, el sistema sigue estos pasos:

* Recibe la contraseña que el usuario ha ingresado.
* Busca en la base de datos el hash almacenado para ese nombre de usuario.
* Utiliza la función `password_verify()` de PHP para comparar la contraseña ingresada con el hash almacenado.

**¿Cómo funciona `password_verify()`?** Esta función toma dos argumentos: la contraseña que el usuario ingresó y el hash almacenado. Internamente, `password_verify()` realiza los siguientes pasos de forma segura:

* Extrae la sal del hash almacenado.
* Aplica el mismo algoritmo `bcrypt` y el mismo factor de costo utilizado para crear el hash a la contraseña ingresada.
* Compara el hash resultante con el hash almacenado.

La función `password_verify()` devuelve `true` solo si los dos hashes coinciden, lo que indica que la contraseña ingresada es correcta. Este proceso se realiza sin revelar la contraseña original ni el hash de una manera insegura.

**4. Gestión de Contraseñas Iniciales (Si Aplica):**

En este sistema, las contraseñas iniciales para los usuarios son generadas internamente por la administración. Sin embargo, es crucial entender que estas contraseñas iniciales **nunca se guardan en texto plano en la base de datos**. Inmediatamente después de ser generadas, pasan por el mismo proceso de hashing utilizando `password_hash()` y solo el hash resultante se almacena en el sistema. La contraseña original nunca se escribe directamente en la base de datos.

**5. Cierre de Sesión Seguro (Logout):**

Cuando un usuario decide cerrar su sesión (logout), el sistema realiza las siguientes acciones para garantizar una salida segura:

* **Invalidación de Variables de Sesión:** Se eliminan todas las variables almacenadas en el servidor que estaban asociadas con la sesión de ese usuario, como el estado de "logueado" y la información del usuario.
* **Eliminación de la Cookie de Sesión:** Se le indica al navegador del usuario que elimine la cookie que identifica su sesión. Esto evita que el navegador envíe automáticamente la identificación de la sesión en futuras peticiones, lo que podría permitir un acceso no autorizado.
* **Destrucción de la Sesión en el Servidor:** Se finaliza la sesión en el lado del servidor, liberando los recursos asociados.

Este proceso asegura que la sesión del usuario se cierre completamente y que se requieran nuevas credenciales para volver a acceder al sistema.

**En resumen, la seguridad de las contraseñas en este sistema se basa en los principios de almacenamiento de representaciones seguras (hashes) utilizando algoritmos robustos como `bcrypt`, la verificación segura sin revelar la contraseña original y un proceso de cierre de sesión completo. Estas medidas están diseñadas para proteger la información de acceso de los usuarios contra diversas amenazas de seguridad.**

Espero que esta explicación más detallada sea útil para tu jefa. ¡No dudes en preguntar si necesitas aclarar algún punto adicional!