<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1); // Solo para desarrollo, quitar en producción

// Configuración de la base de datos
$host = "pdvdesarollo.net";
$dbname = "pdvdesar_MKTINT";
$dbusername = "pdvdesar_MKINT";
$dbpassword = "Mk1ntern@2025!";

// Función para redireccionar
function redirect($url) {
    header("Location: " . $url);
    exit();
}

try {
    // 1. Conexión a la base de datos
    $conn = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbusername,
        $dbpassword,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );

    $conn->exec("SET NAMES 'utf8'");

    error_log("Database connection successful");

    // 2. Solo procesar si es POST
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        redirect("login.html");
    }

    // 3. Obtener y limpiar datos
    $username = trim($_POST["username"] ?? '');
    $username = mb_convert_encoding($username, 'UTF-8', 'auto');
    $password = trim($_POST["password"] ?? '');
    $password = mb_convert_encoding($password, 'UTF-8', 'auto');

    error_log("Username recibido: " . $username);
    error_log("Password recibido: " . $password);

    // 4. Validaciones básicas
    if (empty($username)) {
        throw new Exception("El nombre de usuario es requerido");
    }

    if (empty($password)) {
        throw new Exception("La contraseña es requerida");
    }

    // 5. Buscar usuario
    $stmt = $conn->prepare("SELECT * FROM Usuarios WHERE username = :username LIMIT 1");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch();

    error_log("Datos del usuario encontrado (antes de verificar contraseña): " . print_r($user, true));

    // 6. Verificar usuario y contraseña
    if (!$user) {
        throw new Exception("Usuario o contraseña incorrectos - Usuario no encontrado");
    }

    if (!password_verify(trim($password), trim($user['password']))) {
        throw new Exception("Usuario o contraseña incorrectos - Contraseña incorrecta");
    }

    // 7. Crear sesión
    $_SESSION["loggedIn"] = true;
    $_SESSION["user"] = [
        'id' => $user['id'],
        'username' => $user['username']
    ];

    error_log("Sesión creada: " . print_r($_SESSION, true));
    var_dump($_SESSION); // Para ver la sesión en pantalla
    echo "Autenticación exitosa"; // Para confirmar que llegamos aquí
    redirect("../index.php"); // Descomentar en producción

} catch (PDOException $e) {
    // Error de base de datos
    error_log("Error de BD: " . $e->getMessage());
    echo "Error de BD: " . $e->getMessage();
} catch (Exception $e) {
    // Otros errores
    echo "Error: " . $e->getMessage();
}