<?php
$password_en_texto_plano = "testpassword"; // Reemplaza con la contraseña que quieras hashear
$hashed_password = password_hash($password_en_texto_plano, PASSWORD_DEFAULT);
echo "La contraseña en texto plano es: " . $password_en_texto_plano . "\n";
echo "El hash de la contraseña es: " . $hashed_password . "\n";
?>