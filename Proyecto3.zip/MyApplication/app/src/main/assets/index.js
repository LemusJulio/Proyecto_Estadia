import { toggleDarkMode } from './darkMode.js';

document.getElementById("nodo-principal").addEventListener("click", function() {
    const container = document.querySelector(".mapa-container");
    let nodos = document.querySelectorAll(".nodo-hijo");

    if (nodos.length === 0) {
        const elementos = [
            { texto: "Producción", icono: "https://cdn-icons-png.freepik.com/512/2973/2973740.png", link: "produccion.html"},
            { texto: "Operación y Logística", icono: "https://cdn-icons-png.freepik.com/512/18191/18191216.png", link: "operacion_logistica.html"},
            { texto: "Dirección General", icono: "https://cdn-icons-png.freepik.com/512/10908/10908520.png", link: "direccion_general.html"},
            { texto: "Tecnología", icono: "https://cdn-icons-png.freepik.com/512/778/778631.png", link: "tecnologia.html"},
            { texto: "Sistema de Gestión", icono: "https://cdn-icons-png.freepik.com/512/16517/16517493.png", link: "gestion_calidad.html"},
            { texto: "Seguridad", icono: "https://cdn-icons-png.freepik.com/512/1022/1022382.png", link: "seguridad.html"},
            { texto: "Administración", icono: "https://cdn-icons-png.freepik.com/512/13339/13339430.png", link: "administracion.html"},
            { texto: "TIC's", icono: "https://cdn-icons-png.freepik.com/512/780/780477.png", link: "tics.html"},
            { texto: "Almacén General", icono: "https://cdn-icons-png.freepik.com/512/18771/18771476.png", link: "almacen.html"},
            { texto: "Compras", icono: "https://cdn-icons-png.freepik.com/512/7438/7438697.png", link: "compras.html"}
        ];

        let screenWidth = window.innerWidth;
        let baseRadius = screenWidth > 768 ? 300 : 130;
        let minRadius = 100;
        let maxRadius = screenWidth / 2 - parseInt(getComputedStyle(document.documentElement).getPropertyValue('--nodo-max-size')) / 2;
        let radius = Math.max(minRadius, Math.min(baseRadius, maxRadius));

        elementos.forEach((elem, i) => {
            let nodo = document.createElement("div");
            nodo.classList.add("nodo", "nodo-hijo");
            nodo.innerHTML = `<img src="${elem.icono}" alt="${elem.texto}"><span>${elem.texto}</span>`;
            nodo.style.backgroundColor = elem.color;
            nodo.addEventListener("click", function() {
                window.location.href = elem.link;
            });
            container.appendChild(nodo);

            let angle = (i / elementos.length) * (2 * Math.PI);
            let x = radius * Math.cos(angle);
            let y = radius * Math.sin(angle);
            nodo.style.setProperty('--x', `${x}px`);
            nodo.style.setProperty('--y', `${y}px`);
            nodo.style.opacity = "1";
            nodo.style.display = "flex";
        });
    } else {
        nodos.forEach(nodo => nodo.remove());
    }
});

document.getElementById("toggleDarkMode").addEventListener("click", toggleDarkMode);

document.getElementById('instructionsBtn').addEventListener('click', () => {
    Swal.fire({
        title: '¿Cómo funciona?',
        html: `
            <div style="text-align: left">
                <p>1. Presiona el círculo central con el logo de Diseño Visual para desplegar las áreas de la empresa.</p>
                <p>2. Cada área tiene sus procedimientos.</p>
                <p>3. Al oprimir el círculo del área de tu interés, te enviará a otro mapa, dónde encontrarás los procedimientos del área correspondiente.</p>
                <p>4. Siempre en la parte superior izquierda de la pantalla tendrás un botón para hacer el fondo oscuro para tu cómodidad.</p>
            </div>
        `,
        icon: 'info',
        confirmButtonText: 'Entendido',
        confirmButtonColor: '#33CC66',
        customClass: {
            popup: 'swal-wide'
        }
    });
});
