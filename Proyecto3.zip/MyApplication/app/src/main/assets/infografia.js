document.addEventListener('DOMContentLoaded', () => {
    // Usar constantes para valores reutilizados
    const MOBILE_BREAKPOINT = 768;
    const ZOOM_STEP = 0.1;
    const MAX_SCALE = 5;
    const MIN_SCALE = 0.5;

    // Añadir gestión de errores
    try {
        const element = document.getElementById('image-container');
        if (!element) throw new Error('Container element not found');

        // Optimizar detección de dispositivo
        const isMobile = ('ontouchstart' in window) || 
                        (navigator.maxTouchPoints > 0) || 
                        (navigator.msMaxTouchPoints > 0);

        // Mejorar configuración de Panzoom con opciones de rendimiento
        const panzoomConfig = {
            maxScale: MAX_SCALE,
            minScale: MIN_SCALE,
            contain: 'outside',
            startScale: 1,
            step: ZOOM_STEP,
            animate: true,
            duration: 200,
            easing: 'ease-out',
            // Optimización de rendimiento
            acceleration: true,
            transformOrigin: 'center center',
            // Mejorar el comportamiento táctil
            touchAction: 'none',
            // Prevenir conflictos de eventos
            excludeClass: 'control-btn'
        };

        const panzoom = Panzoom(element, panzoomConfig);

        // Añadir mejoras de accesibilidad
        const setupAccessibility = () => {
            const controls = document.querySelectorAll('.control-btn');
            controls.forEach(control => {
                control.setAttribute('role', 'button');
                control.setAttribute('tabindex', '0');
                control.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        control.click();
                    }
                });
            });
        };

        // Ejecutar configuración de accesibilidad
        setupAccessibility();

        // Habilitar el arrastre
        element.style.cursor = 'grab';
        element.addEventListener('mousedown', () => {
            element.style.cursor = 'grabbing';
        });
        element.addEventListener('mouseup', () => {
            element.style.cursor = 'grab';
        });

        // Controles comunes
        document.getElementById('zoomIn').addEventListener('click', () => {
            panzoom.zoomIn();
        });

        document.getElementById('zoomOut').addEventListener('click', () => {
            panzoom.zoomOut();
        });

        document.getElementById('resetZoom').addEventListener('click', () => {
            panzoom.reset();
        });

        // PC específico
        if (!isMobile) {
            element.addEventListener('wheel', (event) => {
                if (event.ctrlKey) {
                    event.preventDefault();
                    panzoom.zoomWithWheel(event);
                }
            });

            document.addEventListener('keydown', (event) => {
                switch(event.key) {
                    case '+':
                    case '=':
                        panzoom.zoomIn();
                        break;
                    case '-':
                        panzoom.zoomOut();
                        break;
                    case '0':
                        panzoom.reset();
                        break;
                }
            });

            // Botón de ayuda con SweetAlert2
            const helpButton = document.getElementById('helpButton');
            if (helpButton) {
                helpButton.addEventListener('click', () => {
                    Swal.fire({
                        title: 'Atajos de Teclado (Controles de Computadora)',
                        html: `
                            <div style="text-align: left">
                                <p><kbd>+</kbd> o <kbd>=</kbd> : Aumentar zoom</p>
                                <p><kbd>-</kbd> : Reducir zoom</p>
                                <p><kbd>Número 0</kbd> : Restablecer zoom</p>
                                <p><kbd>Ctrl + Rueda del ratón</kbd> : Zoom gradual</p>
                            </div>
                        `,
                        icon: 'info',
                        confirmButtonText: 'Entendido',
                        customClass: {
                            popup: 'keyboard-shortcuts-popup'
                        }
                    });
                });
            }
        }

        // Dark mode toggle con persistencia
        const moonImage = document.getElementById('toggleImage');
        const body = document.body;
        let isDarkMode = localStorage.getItem('darkMode') === 'true';

        // Aplicar modo oscuro guardado
        if (isDarkMode) {
            body.classList.add('dark-mode');
        }

        moonImage.addEventListener('click', () => {
            body.classList.toggle('dark-mode');
            isDarkMode = !isDarkMode;
            localStorage.setItem('darkMode', isDarkMode);
        });

        // Manejar cambios de tamaño de ventana
        window.addEventListener('resize', debounce(() => {
            const newIsMobile = window.innerWidth <= MOBILE_BREAKPOINT;
            if (newIsMobile !== isMobile) {
                location.reload(); // Reiniciar con la nueva configuración
            }
        }, 250));

        // Añadir manejo de gestos táctiles mejorado
        let lastTouchDistance = 0;
        element.addEventListener('touchstart', (e) => {
            if (e.touches.length === 2) {
                lastTouchDistance = getTouchDistance(e.touches);
            }
        }, { passive: true });

        // Mejorar el rendimiento del resize
        const resizeObserver = new ResizeObserver(debounce(() => {
            panzoom.reset();
        }, 250));
        resizeObserver.observe(element);

        // Añadir el código del infoButton antes del return
        const infoButton = document.getElementById('infoButton');
        if (infoButton) {
            infoButton.addEventListener('click', () => {
                Swal.fire({
                    title: '¿Cómo funciona?',
                    html: `
                        <div style="text-align: left">
                            <h3>Controles básicos:</h3>
                            <p>🔍 <strong>Zoom:</strong> Usa los botones + y - para acercar y alejar la imagen</p>
                            <p>🔄 <strong>Restablecer:</strong> El botón de reset devuelve la imagen a su tamaño original</p>
                            <p>🖱️ <strong>Arrastrar:</strong> Haz clic y arrastra para mover la imagen</p>
                            <p>🌙 <strong>Modo oscuro:</strong> Cambia entre modo claro y oscuro</p>
                            <p>🏠 <strong>Inicio:</strong> Vuelve a la página principal</p>
                            <p>↩️ <strong>Volver:</strong> Regresa a la página anterior</p>

                            
                            <h3>Gestos táctiles:</h3>
                            <p>👆 <strong>Pellizcar:</strong> Usar dos dedos para zoom</p>
                            <p>👆 <strong>Arrastrar:</strong> Deslizar con un dedo para mover</p>
                            
                            <h3>Atajos de teclado (PC):</h3>
                            <p>➕ <strong>Zoom in:</strong> Tecla + o =</p>
                            <p>➖ <strong>Zoom out:</strong> Tecla -</p>
                            <p>0️⃣ <strong>Reset:</strong> Tecla 0</p>
                        </div>
                    `,
                    icon: 'info',
                    confirmButtonText: 'Entendido',
                    customClass: {
                        container: 'help-popup',
                        popup: 'help-popup-content'
                    }
                });
            });
        }

        // Después añadir el return
        return () => {
            resizeObserver.disconnect();
            panzoom.destroy();
        };
    } catch (error) {
        console.error('Error initializing viewer:', error);
        // Mostrar mensaje de error al usuario
        Swal.fire({
            title: 'Error',
            text: 'Hubo un problema al cargar el visor de imágenes',
            icon: 'error'
        });
    }
});

// Utilidad para debounce
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
    
}
