package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private WebView myWebView;
    private WebSettings myWebSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView mywebView = findViewById(R.id.webview);
        WebSettings mywebSettings = mywebView.getSettings();
        mywebSettings.setJavaScriptEnabled(true);
        mywebSettings.setAllowFileAccess(true);
        mywebSettings.setDomStorageEnabled(true);
        mywebSettings.setAllowFileAccessFromFileURLs(true);
        mywebSettings.setAllowUniversalAccessFromFileURLs(true);
        mywebView.loadUrl("file:///android_asset/index.html");
        mywebView.setWebViewClient(new WebViewClient());
    }

    @Override
    public void onBackPressed(){
        if (myWebView.canGoBack()){
            myWebView.goBack();
        }else {
            super.onBackPressed();
        }
    }
}