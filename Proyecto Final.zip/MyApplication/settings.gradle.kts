// settings.gradle.kts (a nivel de proyecto)

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS) // O la configuración que uses
    repositories {
        google()       // Necesario para dependencias de AndroidX
        mavenCentral() // Necesario para muchas otras bibliotecas
    }
}

rootProject.name = "My Application"
include(":app")