plugins {
    alias(libs.plugins.android.application)
    // Asegúrate de tener el plugin de Kotlin si usas Kotlin en tu app
    // id("org.jetbrains.kotlin.android") version "x.y.z" // Descomenta y ajusta si es necesario
}

android {
    namespace = "com.example.myapplication"
    compileSdk = 35 // Considera usar libs.versions.compileSdk si está definido en tu toml

    sourceSets {
        named("main") {
            assets.srcDirs("src/main/assets")
        }
    }

    defaultConfig {
        applicationId = "com.example.myapplication"
        minSdk = 24 // Considera usar libs.versions.minSdk
        targetSdk = 35 // Considera usar libs.versions.targetSdk
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // --- LÍNEA AÑADIDA AQUÍ ---
        multiDexEnabled = true
        // -------------------------
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        // Si usas Java 11 o superior. Si usas Kotlin, esto podría no ser necesario
        // o se maneja de forma diferente con las opciones de Kotlin.
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    // Si usas Kotlin, añade esto (ajusta la versión JVM si es necesario):
    // kotlinOptions {
    //     jvmTarget = "11"
    // }
}

dependencies {

    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // --- LÍNEAS AÑADIDAS AQUÍ ---
    implementation("androidx.webkit:webkit:1.6.1")
    implementation("androidx.multidex:multidex:2.0.1")
    // -------------------------

    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}