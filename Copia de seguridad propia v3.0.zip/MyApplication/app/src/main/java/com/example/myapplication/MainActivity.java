package com.example.myapplication;

import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.os.Bundle;
import android.webkit.*;
import android.util.Log;
import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {
    private WebView myWebView;
    private static final String WEBVIEW_ERROR_TAG = "WebViewError";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clearAppCache();
        myWebView = findViewById(R.id.webview);

        if (myWebView != null) {
            myWebView.clearCache(true);
            myWebView.clearHistory();
            configureWebView();
        }
    }

    private void configureWebView() {
        WebSettings webSettings = myWebView.getSettings();

        // Configuraciones esenciales
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);

        // Configuración de caché
        // webSettings.setCacheMode(WebSettings.LOAD_DEFAULT); // Ejemplo: Carga desde caché si es reciente, sino desde la red
        webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK); // Otra opción común

        webSettings.setDatabaseEnabled(true);

        // Configuración offline
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);

        // Debug
        myWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) {
                Log.d("WebView Console", String.format("%s @ %d: %s",
                        cm.sourceId(), cm.lineNumber(), cm.message()));
                return true;
            }
        });

        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource(WebView view, String url) {
                Log.d("WebView Resource", "Loading: " + url);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d("WebView", "Page loaded: " + url);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                Log.e("WebView Error", "URL: " + request.getUrl() + " Error: " + error.getDescription());
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(WEBVIEW_ERROR_TAG, "Error: " + description);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();

                if (url.startsWith("whatsapp://") || url.startsWith("https://api.whatsapp.com")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(url));
                        startActivity(intent);
                        return true;
                    } catch (Exception e) {
                        Log.e("WhatsApp", "Error opening WhatsApp: " + e.getMessage());
                        return false;
                    }
                }
                return false;
            }
        });

        myWebView.addJavascriptInterface(new WebAppInterface(this), "Android");
        myWebView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (myWebView != null) {
            myWebView.resumeTimers();
        }
    }

    @Override
    protected void onPause() {
        if (myWebView != null) {
            myWebView.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (myWebView != null) {
            myWebView.destroy();
        }
        super.onDestroy();
    }

    private void clearAppCache() {
        try {
            File dir = getCacheDir();
            if (dir != null && dir.isDirectory()) {
                deleteDir(dir);
            }
        } catch (Exception e) {
            Log.e("Cache", "Error clearing cache", e);
        }
    }

    private boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (String child : children) {
                boolean success = deleteDir(new File(dir, child));
                if (!success) {
                    return false;
                }
            }
            return dir.delete();
        } else if (dir != null && dir.isFile()) {
            return dir.delete();
        }
        return false;
    }

    public class WebAppInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        WebAppInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void clearAppCache() {
            runOnUiThread(() -> {
                if (myWebView != null) {
                    myWebView.clearCache(true);
                    myWebView.clearHistory();
                }
                MainActivity.this.clearAppCache();
            });
        }

        @JavascriptInterface
        public void restartApp() {
            runOnUiThread(() -> {
                Intent intent = getPackageManager()
                        .getLaunchIntentForPackage(getPackageName());
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    finish();
                }
            });
        }

        public void goBack() {
            runOnUiThread(() -> {
                if (myWebView != null && myWebView.canGoBack()) {
                    myWebView.goBack();
                } else {
                    finish();
                }
            });
        }
    }
}