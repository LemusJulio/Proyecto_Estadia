package com.example.myapplication;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ConsoleMessage;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.util.Log;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView myWebView;
    private static final String WEBVIEW_CONSOLE_TAG = "WebViewConsole";
    private static final String WEBVIEW_ERROR_TAG = "WebViewError";
    private static final String WEBVIEW_DEBUG_TAG = "WebViewDebug";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = findViewById(R.id.webview);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccessFromFileURLs(true);
        webSettings.setAllowUniversalAccessFromFileURLs(true);

        // Añadir interfaz JavaScript
        myWebView.addJavascriptInterface(new WebAppInterface(this), "Android");

        // Configurar WebViewClient con depuración
        myWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                Log.e(WEBVIEW_ERROR_TAG, "Error loading URL: " + request.getUrl() +
                        " - Description: " + error.getDescription());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                Log.d(WEBVIEW_DEBUG_TAG, "Page loaded successfully: " + url);
                // Inyectar JavaScript para verificar el contenido
                view.evaluateJavascript(
                        "(function() { return document.documentElement.outerHTML; })();",
                        html -> Log.d(WEBVIEW_DEBUG_TAG, "Page content: " + html)
                );
            }
        });

        // Configurar WebChromeClient para logs de consola
        myWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(WEBVIEW_CONSOLE_TAG, String.format("%s -- From line %d of %s",
                        consoleMessage.message(),
                        consoleMessage.lineNumber(),
                        consoleMessage.sourceId()));
                return true;
            }
        });

        // Cargar la página
        Log.d(WEBVIEW_DEBUG_TAG, "Loading URL: file:///android_asset/index.html");
        myWebView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @android.webkit.JavascriptInterface
        public void goBack() {
            runOnUiThread(() -> {
                if (myWebView.canGoBack()) {
                    myWebView.goBack();
                } else {
                    finish();
                }
            });
        }
    }
}