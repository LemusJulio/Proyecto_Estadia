document.addEventListener('DOMContentLoaded', () => {
  const moonImage = document.getElementById('toggleImage');
  const body = document.body; // Para modificar el fondo
  let isMoon = false; // Comienza con el sol como imagen principal

  // Color de fondo original (cuando está el sol)
  const originalBackgroundColor = "linear-gradient(300deg, #5fb0db 0%, #17b598 60%, #86e9a4 100%)"; // Fondo claro con gradiente
  // Color cuando cambia a la luna (fondo oscuro con gradiente)
  const darkBackgroundColor = "linear-gradient(300deg, #1f2f56 0%, #122d44 60%, #7b94b5 100%)"; // Fondo oscuro

  // Establecer el fondo inicial
  body.style.background = originalBackgroundColor;

  moonImage.addEventListener('click', () => {
      if (isMoon) {
          // Volver al sol
          moonImage.src = "https://png.pngtree.com/png-clipart/20250103/original/pngtree-icons---vector-sun-in-summer-png-image_4992596.png"; // Sol
          body.style.background = originalBackgroundColor; // Volver al fondo original
      } else {
          // Cambiar a la luna
          moonImage.src = "https://static.vecteezy.com/system/resources/thumbnails/040/215/712/small/ai-generated-moon-clip-art-free-png.png"; // Luna
          body.style.background = darkBackgroundColor; // Fondo oscuro cuando aparece la luna
      }
      isMoon = !isMoon;
  });

  const zoomInButton = document.getElementById('zoomIn');
  const zoomOutButton = document.getElementById('zoomOut');
  const image = document.getElementById('image');
  let scale = 1; // Comenzar con escala 1 para evitar que la imagen se vea recortada inicialmente

  const imageContainer = document.querySelector('.image-container');
  let isDragging = false;
  let startX, startY, scrollLeft, scrollTop;

  // Modificar la función de zoom
  function updateZoom(newScale) {
      scale = newScale;
      image.style.transform = `scale(${scale})`;
      
      // Centrar el scroll después del zoom
      const scrollableX = (image.offsetWidth * scale - imageContainer.offsetWidth) / 2;
      const scrollableY = (image.offsetHeight * scale - imageContainer.offsetHeight) / 2;
      
      if (scale > 1) {
          imageContainer.scrollLeft = scrollableX;
          imageContainer.scrollTop = scrollableY;
          imageContainer.style.cursor = 'grab';
      } else {
          imageContainer.style.cursor = 'default';
      }
  }

  zoomInButton.addEventListener('click', () => {
      updateZoom(scale + 0.3);
  });

  zoomOutButton.addEventListener('click', () => {
      if (scale > 1) {
          updateZoom(Math.max(1, scale - 0.3));
      }
  });

  // Funciones de arrastre mejoradas
  const startDragging = (e) => {
      if (scale <= 1) return;
      isDragging = true;
      startX = e.type === 'mousedown' ? e.pageX : e.touches[0].pageX;
      startY = e.type === 'mousedown' ? e.pageY : e.touches[0].pageY;
      scrollLeft = imageContainer.scrollLeft;
      scrollTop = imageContainer.scrollTop;
      imageContainer.style.cursor = 'grabbing';
  };

  const drag = (e) => {
      if (!isDragging || scale <= 1) return;
      e.preventDefault();
      const x = e.type === 'mousemove' ? e.pageX : e.touches[0].pageX;
      const y = e.type === 'mousemove' ? e.pageY : e.touches[0].pageY;
      const moveX = (x - startX);
      const moveY = (y - startY);
      imageContainer.scrollLeft = scrollLeft - moveX;
      imageContainer.scrollTop = scrollTop - moveY;
  };

  const stopDragging = () => {
      isDragging = false;
      imageContainer.style.cursor = scale > 1 ? 'grab' : 'default';
  };

  // Eventos para PC
  imageContainer.addEventListener('mousedown', startDragging);
  document.addEventListener('mousemove', drag);
  document.addEventListener('mouseup', stopDragging);
  document.addEventListener('mouseleave', stopDragging);

  // Eventos para móvil
  imageContainer.addEventListener('touchstart', startDragging);
  imageContainer.addEventListener('touchmove', drag);
  imageContainer.addEventListener('touchend', stopDragging);
});
